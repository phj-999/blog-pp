export interface IDepartmentParams extends IDepartment {
    content: string
}
export interface IDepartment {
    id?: string
    name: string
    number: number
    status: true
}
