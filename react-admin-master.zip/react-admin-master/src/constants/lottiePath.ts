export const ClosePath = 'https://assets10.lottiefiles.com/temp/lf20_1m8bBV.json'

export const LoginPath = 'https://assets3.lottiefiles.com/private_files/lf30_irb2v6ie.json'
