import { FormProps } from 'antd';

export const LayoutCol: FormProps = {
    labelCol: { span: 4 },
    wrapperCol: { span: 16 },
}

export const Min_Width = 460
