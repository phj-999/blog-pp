// eslint-disable-next-line import/prefer-default-export
export const BASE = process.env.NODE_ENV === 'development' ? '/api' : '/adminApi/'
